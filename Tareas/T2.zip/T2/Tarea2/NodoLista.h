#pragma once
#include "pch.h"
#include <iostream>

using namespace std;

class NodoLista
{
public:
	int numero;
	NodoLista* siguiente;

	NodoLista(int numero_) {
		numero = numero_;
		siguiente = nullptr;
	}

};

