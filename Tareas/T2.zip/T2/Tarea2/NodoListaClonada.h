#pragma once
#include "pch.h"
#include <iostream>

using namespace std;

class NodoListaClonada
{
public:
	int numero;
	NodoListaClonada* siguiente;

	NodoListaClonada(int numero_) {
		numero = numero_;
		siguiente = nullptr;
	}



};
