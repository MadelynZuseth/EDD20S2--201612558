#pragma once
#include "pch.h"
#include <iostream>

using namespace std;
class Pila
{
public:
	int dato = 0;
	NodoPila *primero;
	NodoPila *ultimo;

	Pila(){
		primero= nullptr;
		ultimo = nullptr;
	}
	
	void push(int numero);
	void pop();
	void agregarLista();
};

