#pragma once
#include "pch.h"
#include <iostream>

using namespace std;

class ListaClonada
{
public:
	NodoListaClonada *primero;
	NodoListaClonada *ultimo;

	ListaClonada(){
		primero = nullptr;
		ultimo = nullptr;
	}

	void ingresar(int numero);
	void mostrar();

};

