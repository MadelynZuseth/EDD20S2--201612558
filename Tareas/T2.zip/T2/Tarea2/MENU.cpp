#pragma once
#include "pch.h"
#include <iostream>

using namespace std;

ListaSimple *lista = new ListaSimple();
ListaClonada *clonada = new ListaClonada();
Pila *pila = new Pila();

void MENU::menu() {
	int opcion;
	int numero;
	cout << "MENU" << endl;
	cout << "1. Ingresar lista" << endl;
	cout << "2. Clonar cola" << endl;
	cout << "3. Mostrar listas" << endl;
	cin >> opcion;

	if (opcion == 1) {
		cout << "Ingrese numero"<<endl;
		cin >> numero;
		lista->ingresar(numero);
		cout << "Dato ingresado correctamente" << endl;
		menu();
	}
	else if (opcion == 2) {
		lista->agregarpila();
		pila->agregarLista();
	}
	else if (opcion == 3) {
		cout << "Lista simple" << endl;
		lista->mostrar();
		cout << "Lista Clonada" << endl;
		clonada->mostrar();
	}
}