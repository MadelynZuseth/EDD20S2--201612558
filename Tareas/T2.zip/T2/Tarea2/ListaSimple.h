#pragma once
#include "pch.h"
#include <iostream>

using namespace std;

class ListaSimple 
{
public:
	int n;
	NodoLista *primero;
	NodoLista *ultimo;

	ListaSimple() {
		primero = nullptr;
		ultimo = nullptr;
	}

	void ingresar(int numero);
	void mostrar();
	void agregarpila();
};

