#pragma once
class MENU
{
public:

	MENU() {

	}

	void menu();

};

