#pragma once
class NodoPila
{
public:

	NodoPila *siguiente;
	int numero;
	NodoPila(int numero_) {
		numero = numero_;
		siguiente = nullptr;
	}

	void push(int numero_);
	void pop();
};

 