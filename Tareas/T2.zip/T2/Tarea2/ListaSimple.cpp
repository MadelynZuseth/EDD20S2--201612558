#pragma once
#include "pch.h"
#include <iostream>
#include <string>

Pila *pila = new Pila();

void ListaSimple::ingresar(int numero) {
	
	NodoLista *auxiliar = new NodoLista(numero);
	if (primero != nullptr) {
		primero = auxiliar;
		ultimo = auxiliar;
	}
	else {
		ultimo->siguiente = auxiliar;
		ultimo = auxiliar;
	}
}

void ListaSimple::mostrar() {
	NodoLista *auxiliar = primero;
	while (auxiliar != nullptr) {
		cout << auxiliar->numero << endl;
		auxiliar = auxiliar->siguiente;
	}
}

void ListaSimple::agregarpila() {
	NodoLista *auxiliar = primero;
	if (auxiliar != nullptr) {
		if (auxiliar->siguiente != nullptr) {
			while (auxiliar->siguiente != ultimo) {
				auxiliar = auxiliar->siguiente;
			}
			pila->push(auxiliar->numero);
			ultimo = auxiliar;
			agregarpila();
		}else{
			pila->push(auxiliar->numero);
			ultimo = nullptr;
			primero = nullptr;
		}
	}
}
