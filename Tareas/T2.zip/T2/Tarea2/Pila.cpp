#pragma once
#include "pch.h"
#include <iostream>

using namespace std;

ListaClonada *clonada = new ListaClonada();

void Pila::push(int numero) {
	NodoPila *auxiliar = new NodoPila(numero);

	if (primero == nullptr) {
		primero = auxiliar;
		ultimo = auxiliar;
	}
	else {
		ultimo->siguiente = auxiliar;
		ultimo = auxiliar;
	}
}

void Pila::pop() {
	NodoPila *auxiliar = primero;
	if (primero != ultimo) {
		while (auxiliar->siguiente != ultimo) {
			auxiliar = auxiliar->siguiente;
		}
		dato = auxiliar->numero;
		clonada->ingresar(dato);
		ultimo = auxiliar;
	}
	else if (primero == nullptr) {
		dato = auxiliar->numero;
		clonada->ingresar(dato);
		primero = nullptr;
		ultimo = nullptr;
	}
	else {
		cout << "no hay datos en la lista" << endl;
	}
}

void Pila::agregarLista() {
	while (primero != nullptr) {
		pop();
	}
}
	

