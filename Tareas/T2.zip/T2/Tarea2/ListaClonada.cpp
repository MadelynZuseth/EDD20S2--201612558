#include "pch.h"

ListaSimple *simple = new ListaSimple();
void ListaSimple::ingresar(int numero) {

	NodoListaClonada *auxiliar = new NodoListaClonada(numero);
	NodoLista *aux = new NodoLista(numero);
	if (primero != nullptr) {
		primero = auxiliar;
		ultimo = auxiliar;
	}
	else {
		ultimo->siguiente = auxiliar;
		ultimo = auxiliar;
	}
}

void ListaSimple::mostrar() {
	NodoLista *auxiliar = primero;
	while (auxiliar != nullptr) {
		cout << auxiliar->numero << endl;
		auxiliar = auxiliar->siguiente;
	}
}

